# ShroomClient NextGen

Have you checked out Shroom client? Its the FRESHEST blatant client on intent. You can save your accounts BLOCK the ban
packets. It supports 1.7-1.20.4 servers, that means you can play on probably any server you can imagine. It works on mac
AND linux as well as windows some of you guys can't play on clients because they only work on windows but this one is
different. By default it runs on the intent launcher you can also play it in the vanilla minecraft launcher that means
you can use your 2FA Microsoft Accounts but if you're fine with using the alt manager in mushroom that's built-in you
can also play on mojang and you can play on most microsoft accounts. This client is undetectable on basically every
server and tbh you can probably configurate it to bypass every server it's gonna have configs coming soon but everything
is in the cloud already that means if you play on 1 computer log off join on another computer you're still gonna have
all your settings and everything there.

can we add a rat yet?
